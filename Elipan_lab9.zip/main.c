#include <stdio.h>

#include "cdecl.h"

void PRE_CDECL fibonacci ( int ) POST_CDECL; 

int main( void )
{
  int n;

  printf("Enter a number: ");
  scanf("%d", &n);
  
  fibonacci(n);
  return 0;
}